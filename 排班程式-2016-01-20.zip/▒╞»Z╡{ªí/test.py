#讀取fileMemberSetting.txt
file = open('fileMemberSetting.txt', 'w', encoding = 'UTF-8')
file.write('strMemberArraySelect = arrayMemberPartial\n')
file.write('pointNextWho = 明旭\n')
file.close()

